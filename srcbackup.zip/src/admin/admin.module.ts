import { Module } from '@nestjs/common';
import { AdminController } from './admin.controller';
import { AdminProductsController } from './admin.products.controller';
import { ProductsService } from 'src/models/products.service';
@Module({
  controllers: [AdminController, AdminProductsController],
  providers: [ProductsService],
})
export class AdminModule {}
